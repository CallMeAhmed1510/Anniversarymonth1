'use client'

import { useCallback, useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { DoorOpen } from 'lucide-react'
import { Grizzly, SpeechBubble } from '@/components/grizzly'

type Room = { q: string; options: string[]; correct: number }

const ROOMS: Room[] = [
  {
    q: 'What discord bot did we started talking because of ?',
    options: ['Dyno bot', 'Welcomer bot', 'Arcane bot', 'OwO bot'],
    correct: 3,
  },
  {
    q: 'Who was the first to go crazy about us starting dating?',
    options: ['Snowy', 'Luna', 'Daniel', 'Leo'],
    correct: 1,
  },
  {
    q: 'Who said i love you first?',
    options: ['Me', 'You', 'Zoro???', 'Peak- 😂?'],
    correct: 1,
  },
  {
    q: 'If i said ill bite you, where would i almost always say i would?',
    options: ['Cheek', 'Ear', 'Hips', 'Neck'],
    correct: 3,
  },
]

/** escalating tsundere reactions, indexed by mistake number (1..3) */
const RAGE = [
  { emotion: '😼', text: '*tip toe* …never saw that one 🐾' },
  { emotion: '💢', text: "hmph! n-not like i wanted you to miss it…" },
  { emotion: '💢', text: 'THIS ONE!! 👉💥' },
]

type Bear = 'idle' | 'steal' | 'rage' | 'celebrate'

export function Quiz({ onDone }: { onDone: () => void }) {
  const [room, setRoom] = useState(0)
  const [removed, setRemoved] = useState<number[]>([])
  const [mistakes, setMistakes] = useState(0)
  const [busy, setBusy] = useState(false)
  const [bear, setBear] = useState<Bear>('idle')
  const [pointing, setPointing] = useState(false)

  const current = ROOMS[room]

  // reset per-room state whenever we enter a new room
  useEffect(() => {
    setRemoved([])
    setMistakes(0)
    setBusy(false)
    setBear('idle')
    setPointing(false)
  }, [room])

  const advance = useCallback(() => {
    if (room === ROOMS.length - 1) {
      onDone()
    } else {
      setRoom((r) => r + 1)
    }
  }, [room, onDone])

  function choose(i: number) {
    if (busy || removed.includes(i)) return

    if (i === current.correct) {
      setBusy(true)
      setBear('celebrate')
      window.setTimeout(advance, 1650)
      return
    }

    // wrong answer → escalate
    const n = Math.min(mistakes + 1, 3)
    setMistakes(n)
    setBusy(true)
    setBear(n >= 3 ? 'rage' : 'steal')

    window.setTimeout(() => {
      setRemoved((prev) => [...prev, i])
      if (n >= 3) {
        setPointing(true)
        setBear('rage')
      } else {
        setBear('idle')
      }
      setBusy(false)
    }, 1500)
  }

  const reaction =
    bear === 'celebrate'
      ? { emotion: '💖', text: 'hehe yesss — come here 💖' }
      : mistakes > 0 && (bear === 'steal' || bear === 'rage')
        ? RAGE[mistakes - 1]
        : null

  return (
    <div className="flex w-full flex-col items-center gap-6">
      {/* progress pips */}
      <div className="flex items-center gap-2">
        {ROOMS.map((_, i) => (
          <span
            key={i}
            className={`h-1.5 rounded-full transition-all ${
              i === room ? 'w-8 bg-wax' : i < room ? 'w-4 bg-gilt' : 'w-4 bg-secondary'
            }`}
          />
        ))}
      </div>

      {/* the sliding room */}
      <div className="relative w-full max-w-md overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={room}
            initial={{ x: '110%', opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            exit={{ x: '-110%', opacity: 0 }}
            transition={{ type: 'spring', stiffness: 90, damping: 18 }}
            className="room-wall relative overflow-hidden rounded-3xl border border-gilt/30 p-6 pr-14 shadow-[0_20px_60px_-25px_rgba(0,0,0,0.9)]"
          >
            {/* doorway on the right */}
            <div className="pointer-events-none absolute inset-y-4 right-3 flex w-8 items-center justify-center rounded-lg border-2 border-gilt/40 bg-black/30">
              <DoorOpen
                className={`h-5 w-5 transition-colors ${
                  bear === 'celebrate' ? 'text-gilt' : 'text-gilt/40'
                }`}
                aria-hidden="true"
              />
            </div>

            <p className="mb-1 font-serif text-xs tracking-[0.3em] text-gilt/70 uppercase">
              Room {room + 1} of {ROOMS.length}
            </p>
            <h2 className="mb-5 text-balance font-serif text-2xl leading-tight text-foreground">
              {current.q}
            </h2>

            <div className="flex flex-col gap-3">
              <AnimatePresence initial={false}>
                {current.options.map((opt, i) =>
                  removed.includes(i) ? null : (
                    <motion.button
                      key={opt}
                      type="button"
                      layout
                      onClick={() => choose(i)}
                      disabled={busy}
                      initial={{ opacity: 1 }}
                      exit={{
                        x: -220,
                        opacity: 0,
                        rotate: -12,
                        transition: { duration: 0.5 },
                      }}
                      whileHover={busy ? undefined : { scale: 1.02 }}
                      whileTap={busy ? undefined : { scale: 0.98 }}
                      animate={
                        pointing && i === current.correct
                          ? {
                              scale: [1, 1.05, 1],
                              boxShadow: [
                                '0 0 0px var(--gilt)',
                                '0 0 26px -2px var(--gilt)',
                                '0 0 0px var(--gilt)',
                              ],
                            }
                          : {}
                      }
                      transition={
                        pointing && i === current.correct
                          ? { duration: 0.9, repeat: Infinity }
                          : undefined
                      }
                      className="relative rounded-xl border border-gilt/30 bg-card/70 px-4 py-3 text-left font-serif text-lg text-foreground backdrop-blur-sm transition-colors hover:border-gilt/70 disabled:cursor-not-allowed focus-visible:ring-2 focus-visible:ring-gilt focus-visible:outline-none"
                    >
                      {opt}
                      {pointing && i === current.correct ? (
                        <motion.span
                          aria-hidden="true"
                          className="absolute -left-7 top-1/2 -translate-y-1/2 text-2xl"
                          animate={{ x: [0, 6, 0] }}
                          transition={{ duration: 0.6, repeat: Infinity }}
                        >
                          👉
                        </motion.span>
                      ) : null}
                    </motion.button>
                  ),
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Grizzly host reacting under the room */}
      <div className="relative flex min-h-[8.5rem] flex-col items-center justify-end gap-2">
        <AnimatePresence mode="wait">
          {reaction ? (
            <SpeechBubble key={reaction.text}>{reaction.text}</SpeechBubble>
          ) : null}
        </AnimatePresence>

        <motion.div
          animate={
            bear === 'steal'
              ? { x: [-120, 0, 120], rotate: [0, 5, 0] }
              : bear === 'rage'
                ? { x: [0, -6, 6, -6, 6, 0] }
                : bear === 'celebrate'
                  ? { y: [0, -22, 0], scale: [1, 1.1, 1] }
                  : { y: [0, -4, 0] }
          }
          transition={{
            duration: bear === 'steal' ? 1.4 : bear === 'rage' ? 0.4 : bear === 'celebrate' ? 0.7 : 2.4,
            repeat: bear === 'idle' || bear === 'rage' ? Infinity : 0,
            ease: 'easeInOut',
          }}
        >
          <Grizzly
            suited
            size={110}
            emotion={
              bear === 'celebrate'
                ? '🥰'
                : bear === 'rage'
                  ? '💢'
                  : bear === 'steal'
                    ? RAGE[Math.max(0, mistakes - 1)].emotion
                    : '🙂'
            }
          />
        </motion.div>
      </div>
    </div>
  )
}
