'use client'

import { motion, type MotionProps } from 'framer-motion'
import { Canvas, useFrame } from '@react-three/fiber'
import { RoundedBox } from '@react-three/drei'
import { useEffect, useRef, useState, type ReactNode } from 'react'
import type { Group } from 'three'
import { cn } from '@/lib/utils'

type GrizzlyProps = {
  /** emoji shown as the facial expression badge, e.g. '😠' */
  emotion?: string
  /** dresses the bear in his dapper black suit */
  suited?: boolean
  /** floating accessory to the upper right, e.g. '💡' */
  accessory?: string
  /** puff of smoke under him when he dashes around */
  puff?: boolean
  size?: number
  className?: string
} & MotionProps

/* ── palette ─────────────────────────────────────────────── */
const FUR = '#a9784b'
const FUR_DARK = '#8a5f36'
const MUZZLE = '#e3c79b'
const INNER_EAR = '#c99b6b'
const DARK = '#141414'
const SUIT = '#161616'
const SHIRT = '#f4efe6'
const TIE = '#0b0b0b'
const SHOE = '#0c0c0c'
const SHOE_SOLE = '#2a2a2a'

/**
 * The 3D mocha-bear model. A chubby, rounded little bear built entirely from
 * primitives, dressed in a black suit with a white collar shirt and black tie.
 */
function BearModel({ suited }: { suited?: boolean }) {
  const group = useRef<Group>(null)

  useFrame((state) => {
    const t = state.clock.elapsedTime
    if (!group.current) return
    // gentle breathing bob + lazy sway so he always feels alive
    group.current.position.y = 0.15 + Math.sin(t * 1.6) * 0.05
    group.current.rotation.y = Math.sin(t * 0.6) * 0.18
    group.current.rotation.z = Math.sin(t * 0.9) * 0.03
  })

  const armColor = suited ? SUIT : FUR

  return (
    <group ref={group} position={[0, 0.15, 0]}>
      {/* ── head ── */}
      <mesh position={[0, 0.62, 0]} scale={[1.12, 1, 1]} castShadow>
        <sphereGeometry args={[0.86, 48, 48]} />
        <meshStandardMaterial color={FUR} roughness={0.85} />
      </mesh>

      {/* ears */}
      {[-1, 1].map((s) => (
        <group key={s} position={[s * 0.62, 1.32, 0.02]}>
          <mesh castShadow>
            <sphereGeometry args={[0.28, 32, 32]} />
            <meshStandardMaterial color={FUR} roughness={0.85} />
          </mesh>
          <mesh position={[0, 0, 0.16]}>
            <sphereGeometry args={[0.15, 24, 24]} />
            <meshStandardMaterial color={INNER_EAR} roughness={0.8} />
          </mesh>
        </group>
      ))}

      {/* muzzle */}
      <mesh position={[0, 0.42, 0.66]} scale={[1.25, 0.92, 0.85]}>
        <sphereGeometry args={[0.36, 40, 40]} />
        <meshStandardMaterial color={MUZZLE} roughness={0.8} />
      </mesh>

      {/* nose */}
      <mesh position={[0, 0.5, 0.99]}>
        <sphereGeometry args={[0.11, 24, 24]} />
        <meshStandardMaterial color={DARK} roughness={0.35} />
      </mesh>

      {/* eyes */}
      {[-1, 1].map((s) => (
        <group key={s} position={[s * 0.32, 0.74, 0.74]}>
          <mesh>
            <sphereGeometry args={[0.1, 24, 24]} />
            <meshStandardMaterial color={DARK} roughness={0.3} />
          </mesh>
          <mesh position={[0.03, 0.04, 0.07]}>
            <sphereGeometry args={[0.032, 16, 16]} />
            <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.4} />
          </mesh>
        </group>
      ))}

      {/* ── body ── */}
      <mesh position={[0, -0.72, 0]} scale={[1.1, 1.05, 0.95]} castShadow>
        <sphereGeometry args={[0.92, 48, 48]} />
        <meshStandardMaterial color={suited ? SUIT : FUR} roughness={suited ? 0.55 : 0.85} />
      </mesh>

      {/* arms */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.92, -0.5, 0.18]} scale={[1, 1.35, 1]} castShadow>
          <sphereGeometry args={[0.3, 32, 32]} />
          <meshStandardMaterial color={armColor} roughness={suited ? 0.55 : 0.85} />
        </mesh>
      ))}
      {/* paws peek out of the sleeves */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.92, -0.95, 0.36]}>
          <sphereGeometry args={[0.2, 24, 24]} />
          <meshStandardMaterial color={FUR} roughness={0.85} />
        </mesh>
      ))}

      {/* suit trousers — a pant leg down each side, tucked into the shoes */}
      {suited
        ? [-1, 1].map((s) => (
            <group key={s}>
              {/* trouser leg */}
              <mesh position={[s * 0.42, -1.28, 0.24]} scale={[1, 1.15, 1]} castShadow>
                <cylinderGeometry args={[0.26, 0.24, 0.72, 28]} />
                <meshStandardMaterial color={SUIT} roughness={0.55} />
              </mesh>
              {/* trouser cuff resting on the shoe */}
              <mesh position={[s * 0.42, -1.6, 0.28]}>
                <cylinderGeometry args={[0.25, 0.25, 0.12, 28]} />
                <meshStandardMaterial color={SUIT} roughness={0.55} />
              </mesh>
            </group>
          ))
        : null}

      {/* feet — bare paws when casual, tucked into trousers when suited */}
      {[-1, 1].map((s) => (
        <mesh key={s} position={[s * 0.42, -1.62, 0.35]} scale={[1, 0.8, 1.25]} castShadow>
          <sphereGeometry args={[0.34, 32, 32]} />
          <meshStandardMaterial color={suited ? SUIT : FUR_DARK} roughness={suited ? 0.55 : 0.85} />
        </mesh>
      ))}

      {/* tiny shoes — little glossy black dress shoes tucked under each foot */}
      {[-1, 1].map((s) => (
        <group key={s} position={[s * 0.42, -1.86, 0.46]}>
          {/* shoe body */}
          <mesh scale={[1, 0.62, 1.35]} castShadow>
            <sphereGeometry args={[0.3, 32, 32]} />
            <meshStandardMaterial color={SHOE} roughness={0.28} metalness={0.15} />
          </mesh>
          {/* rounded toe cap poking forward */}
          <mesh position={[0, -0.02, 0.3]} scale={[0.9, 0.55, 0.7]}>
            <sphereGeometry args={[0.22, 24, 24]} />
            <meshStandardMaterial color={SHOE} roughness={0.22} metalness={0.2} />
          </mesh>
          {/* sole */}
          <mesh position={[0, -0.12, 0.06]} scale={[1, 0.28, 1.4]}>
            <sphereGeometry args={[0.29, 24, 24]} />
            <meshStandardMaterial color={SHOE_SOLE} roughness={0.7} />
          </mesh>
        </group>
      ))}

      {/* ── the suit: white shirt V, collar, and black tie ── */}
      {suited ? (
        <group>
          {/* white shirt front (triangle) */}
          <mesh position={[0, -0.5, 0.82]} rotation={[Math.PI, 0, 0]}>
            <coneGeometry args={[0.34, 0.78, 3]} />
            <meshStandardMaterial color={SHIRT} roughness={0.6} />
          </mesh>

          {/* collar wings */}
          {[-1, 1].map((s) => (
            <mesh
              key={s}
              position={[s * 0.17, -0.16, 0.9]}
              rotation={[0.35, 0, s * 0.7]}
            >
              <boxGeometry args={[0.12, 0.26, 0.04]} />
              <meshStandardMaterial color={SHIRT} roughness={0.6} />
            </mesh>
          ))}

          {/* jacket lapels */}
          {[-1, 1].map((s) => (
            <mesh
              key={s}
              position={[s * 0.28, -0.44, 0.84]}
              rotation={[0.15, 0, s * 0.32]}
            >
              <boxGeometry args={[0.16, 0.72, 0.05]} />
              <meshStandardMaterial color={SUIT} roughness={0.5} />
            </mesh>
          ))}

          {/* tie knot */}
          <mesh position={[0, -0.28, 0.92]}>
            <boxGeometry args={[0.13, 0.14, 0.05]} />
            <meshStandardMaterial color={TIE} roughness={0.45} />
          </mesh>
          {/* tie body */}
          <RoundedBox
            args={[0.16, 0.62, 0.05]}
            radius={0.03}
            smoothness={4}
            position={[0, -0.66, 0.9]}
          >
            <meshStandardMaterial color={TIE} roughness={0.45} />
          </RoundedBox>
        </group>
      ) : null}
    </group>
  )
}

/**
 * Grizzly — the little mocha-bear host, now rendered in glorious 3D.
 * Keeps the exact same props the rest of the app relies on: the `emotion`
 * and `accessory` emojis and the dash `puff` are layered on as reactions
 * above the 3D canvas.
 */
export function Grizzly({
  emotion,
  suited,
  accessory,
  puff,
  size = 120,
  className,
  ...motion_props
}: GrizzlyProps) {
  // R3F's Canvas is client-only — wait until mounted so it never renders
  // during SSR/hydration (which would blank the whole scene).
  const [mounted, setMounted] = useState(false)
  useEffect(() => setMounted(true), [])

  return (
    <motion.div
      className={cn(
        'relative inline-flex select-none items-end justify-center',
        className,
      )}
      style={{ width: size, height: size }}
      {...motion_props}
    >
      {/* the 3D bear fills the box and never intercepts pointer events */}
      <div
        className="absolute inset-0"
        style={{ pointerEvents: 'none' }}
        aria-hidden="true"
      >
        {mounted ? (
          <Canvas
            dpr={[1, 2]}
            gl={{ alpha: true, antialias: true }}
            camera={{ position: [0, 0, 7.2], fov: 34 }}
          >
            {/* warm candlelit lighting to match the scene */}
            <ambientLight intensity={0.65} color="#ffe6c2" />
            <directionalLight position={[3, 5, 4]} intensity={1.4} color="#ffd9a0" />
            <directionalLight position={[-4, 2, 2]} intensity={0.5} color="#c98a5a" />
            <pointLight position={[0, -2, 3]} intensity={0.6} color="#ff9a5a" />
            <BearModel suited={suited} />
          </Canvas>
        ) : null}
      </div>

      {emotion ? (
        <span
          aria-hidden="true"
          className="absolute -right-3 -top-2 z-10 drop-shadow-[0_2px_6px_rgba(0,0,0,0.6)]"
          style={{ fontSize: size * 0.3, lineHeight: 1 }}
        >
          {emotion}
        </span>
      ) : null}

      {accessory ? (
        <motion.span
          aria-hidden="true"
          className="absolute -right-5 -top-3 z-10 drop-shadow-[0_2px_6px_rgba(0,0,0,0.6)]"
          style={{ fontSize: size * 0.42, lineHeight: 1 }}
          initial={{ scale: 0, opacity: 0, rotate: -25 }}
          animate={{ scale: 1, opacity: 1, rotate: 0 }}
          transition={{ type: 'spring', stiffness: 320, damping: 14 }}
        >
          {accessory}
        </motion.span>
      ) : null}

      {puff ? (
        <motion.span
          aria-hidden="true"
          className="absolute -bottom-2 left-0 z-10"
          style={{ fontSize: size * 0.4, lineHeight: 1 }}
          initial={{ opacity: 0, scale: 0.5, x: 0 }}
          animate={{ opacity: [0, 0.9, 0], scale: [0.5, 1.2, 1.6], x: [-4, -18, -34] }}
          transition={{ duration: 0.7, repeat: Infinity }}
        >
          💨
        </motion.span>
      ) : null}
    </motion.div>
  )
}

export function SpeechBubble({
  children,
  className,
}: {
  children: ReactNode
  className?: string
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8, scale: 0.96 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -6, scale: 0.96 }}
      className={cn(
        'relative max-w-[16rem] rounded-2xl border border-gilt/40 bg-card/90 px-5 py-3 text-center font-sans text-2xl leading-snug text-foreground shadow-[0_10px_30px_-12px_rgba(0,0,0,0.7)] backdrop-blur-sm sm:max-w-xs',
        className,
      )}
    >
      {children}
      <span
        aria-hidden="true"
        className="absolute -bottom-1.5 left-1/2 h-3 w-3 -translate-x-1/2 rotate-45 border-b border-r border-gilt/40 bg-card/90"
      />
    </motion.div>
  )
}
