'use client'

import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Grizzly, SpeechBubble } from '@/components/grizzly'

/**
 * Post-quiz fourth-wall beat: Grizzly gets mushy, a paper ball beans him,
 * he plays it off and points you toward the gift.
 */
export function ComedyCutscene({ onDone }: { onDone: () => void }) {
  // 0: fond · 1: paper thrown / startled · 2: *cough* recover · 3: points to gift
  const [step, setStep] = useState(0)

  useEffect(() => {
    const timers = [
      window.setTimeout(() => setStep(1), 2600),
      window.setTimeout(() => setStep(2), 3900),
      window.setTimeout(() => setStep(3), 5200),
      window.setTimeout(() => onDone(), 8200),
    ]
    return () => timers.forEach(clearTimeout)
  }, [onDone])

  const line =
    step === 0
      ? 'hey…you do actually love me…aww….'
      : step === 1
        ? '?!'
        : step === 2
          ? '*cough* *cough*'
          : 'well my maker left you a box as a gift… its just over there →'

  const emotion = step === 1 ? '😲' : step === 2 ? '😳' : step === 3 ? '😌' : '🥰'

  return (
    <div className="relative flex h-80 w-full max-w-md items-center justify-center overflow-hidden">
      {/* thrown crumpled paper */}
      <AnimatePresence>
        {step === 1 ? (
          <motion.span
            key="paper"
            aria-hidden="true"
            className="absolute z-20 text-4xl"
            initial={{ x: 260, y: -140, rotate: 0, opacity: 0 }}
            animate={{
              x: [260, 40, 10, -40],
              y: [-140, -20, 10, 60],
              rotate: [0, 220, 380, 520],
              opacity: [0, 1, 1, 0],
            }}
            transition={{ duration: 1, ease: 'easeIn' }}
          >
            📄
          </motion.span>
        ) : null}
      </AnimatePresence>

      <div className="flex flex-col items-center gap-4">
        <AnimatePresence mode="wait">
          <SpeechBubble key={line}>{line}</SpeechBubble>
        </AnimatePresence>

        <motion.div
          animate={
            step === 1
              ? { x: [0, -18, 12, 0], rotate: [0, -8, 6, 0] }
              : step === 2
                ? { y: [0, -3, 0, -3, 0] }
                : { y: [0, -4, 0] }
          }
          transition={{
            duration: step === 1 ? 0.5 : step === 2 ? 0.8 : 2.2,
            repeat: step === 3 || step === 0 ? Infinity : 0,
            ease: 'easeInOut',
          }}
        >
          <Grizzly suited emotion={emotion} size={150} />
        </motion.div>
      </div>
    </div>
  )
}
