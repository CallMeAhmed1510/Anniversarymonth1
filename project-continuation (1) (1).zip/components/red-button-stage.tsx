'use client'

import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Grizzly, SpeechBubble } from '@/components/grizzly'

/**
 * Grizzly drags in the big gift box, presents a red button, and the whole
 * room cuts to black before a warm spotlight fades up on the next scene.
 */
export function RedButtonStage({ onDone }: { onDone: () => void }) {
  // 0: dragging box in · 1: presenting · 2: red button out / prompt · 3: lights out
  const [step, setStep] = useState(0)
  const [dark, setDark] = useState(false)

  useEffect(() => {
    const timers = [
      window.setTimeout(() => setStep(1), 2400),
      window.setTimeout(() => setStep(2), 4000),
    ]
    return () => timers.forEach(clearTimeout)
  }, [])

  function press() {
    setStep(3)
    setDark(true)
    // hold on black, then hand off to the reveal
    window.setTimeout(onDone, 1500)
  }

  const line =
    step === 0
      ? '*huff*… *puff*… almost… there…'
      : step === 1
        ? 'oh and he said to press…'
        : 'this button? 👉'

  return (
    <div className="relative flex min-h-[26rem] w-full max-w-md flex-col items-center justify-end gap-6 overflow-hidden pb-6">
      <AnimatePresence mode="wait">
        {step < 3 ? (
          <SpeechBubble key={line}>{line}</SpeechBubble>
        ) : null}
      </AnimatePresence>

      {/* the big dragged-in gift box */}
      <div className="relative flex items-end justify-center gap-3">
        <motion.div
          initial={{ x: -320, y: 10, rotate: -6 }}
          animate={{ x: 0, y: 0, rotate: 0 }}
          transition={{ duration: 2.2, ease: 'easeOut' }}
          className="relative"
        >
          <BigGiftBox />
        </motion.div>

        {/* Grizzly, tired from the drag, then presenting the button */}
        <motion.div
          animate={
            step === 0
              ? { rotate: [0, -4, 4, 0], x: [-6, 0, -6] }
              : { y: [0, -4, 0] }
          }
          transition={{
            duration: step === 0 ? 0.9 : 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
          className="relative"
        >
          <Grizzly
            suited
            size={120}
            emotion={step === 0 ? '😮‍💨' : step === 2 ? '😅' : '🙂'}
          />

          {/* the red button he pulls from his pocket */}
          <AnimatePresence>
            {step >= 2 ? (
              <motion.div
                className="absolute -top-6 -right-8"
                initial={{ scale: 0, y: 20, opacity: 0 }}
                animate={{ scale: 1, y: 0, opacity: 1 }}
                transition={{ type: 'spring', stiffness: 300, damping: 15 }}
              >
                <RedButton onPress={press} disabled={step === 3} />
              </motion.div>
            ) : null}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* prompt */}
      <AnimatePresence>
        {step === 2 ? (
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex flex-col items-center gap-3 rounded-2xl border border-gilt/30 bg-card/80 px-6 py-4 backdrop-blur-sm"
          >
            <p className="text-center font-serif text-lg text-foreground">
              Do you want to press the button?
            </p>
            <button
              type="button"
              onClick={press}
              className="rounded-full border border-gilt/50 bg-wax px-8 py-2.5 font-serif text-lg tracking-[0.2em] text-paper uppercase shadow-[0_0_22px_-6px_var(--gilt)] transition-transform hover:scale-105 focus-visible:ring-2 focus-visible:ring-gilt focus-visible:outline-none"
            >
              Yes
            </button>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* lights-out overlay */}
      <AnimatePresence>
        {dark ? (
          <motion.div
            key="blackout"
            className="fixed inset-0 z-50 bg-black"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.18 }}
          />
        ) : null}
      </AnimatePresence>
    </div>
  )
}

function BigGiftBox() {
  return (
    <div className="relative h-40 w-44">
      {/* body */}
      <div className="wrap-texture absolute bottom-0 h-32 w-44 rounded-md border border-black/30 shadow-[inset_0_-14px_28px_rgba(0,0,0,0.4)]" />
      {/* lid */}
      <div className="wrap-texture absolute top-4 left-1/2 h-9 w-48 -translate-x-1/2 rounded-md border border-black/30 shadow-[0_6px_14px_rgba(0,0,0,0.5)]" />
      {/* vertical ribbon */}
      <div className="absolute bottom-0 left-1/2 h-32 w-5 -translate-x-1/2 bg-gilt/80" />
      {/* bow */}
      <div className="absolute top-2 left-1/2 h-8 w-8 -translate-x-1/2 rotate-45 rounded-sm bg-gilt shadow-[0_2px_6px_rgba(0,0,0,0.5)]" />
    </div>
  )
}

function RedButton({
  onPress,
  disabled,
}: {
  onPress: () => void
  disabled?: boolean
}) {
  return (
    <button
      type="button"
      onClick={onPress}
      disabled={disabled}
      aria-label="Press the red button"
      className="group relative block h-16 w-16 rounded-full focus-visible:outline-none"
    >
      <span className="absolute inset-0 rounded-full bg-[#5d0f0a] shadow-[0_6px_0_#3a0906]" />
      <motion.span
        className="absolute inset-x-1 top-0 bottom-1.5 rounded-full bg-gradient-to-b from-[#ff5a4d] to-[#c11f16] shadow-[inset_0_3px_6px_rgba(255,255,255,0.4)] group-active:translate-y-1"
        animate={disabled ? {} : { scale: [1, 1.06, 1] }}
        transition={{ duration: 1.1, repeat: Infinity }}
      />
    </button>
  )
}
