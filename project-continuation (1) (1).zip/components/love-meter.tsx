'use client'

import { useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import { Rocket } from 'lucide-react'
import { Grizzly, SpeechBubble } from '@/components/grizzly'

const BUCKETS = [
  { max: 20, emotion: '😠', text: "Nah That's a lie!" },
  { max: 40, emotion: '😏', text: 'thats right more more' },
  { max: 60, emotion: '😳', text: 'woah okay....maybe abit more?' },
  { max: 80, emotion: '🙈', text: 'hehe' },
  { max: 100, emotion: '🥰', text: 'mmhm keep going...' },
]

type Phase = 'slide' | 'think' | 'idea'

export function LoveMeter({ onStart }: { onStart: () => void }) {
  const [value, setValue] = useState(0)
  const [phase, setPhase] = useState<Phase>('slide')

  const bucket = BUCKETS.find((b) => value <= b.max) ?? BUCKETS[BUCKETS.length - 1]

  function handleChange(v: number) {
    setValue(v)
    if (v >= 100 && phase === 'slide') {
      setPhase('think')
      window.setTimeout(() => setPhase('idea'), 1600)
    }
  }

  const emotion = phase === 'slide' ? bucket.emotion : '🥰'

  return (
    <div className="flex w-full max-w-md flex-col items-center gap-8">
      <p className="text-center font-serif text-sm tracking-[0.4em] text-gilt/80 uppercase">
        how much do you love me?
      </p>

      {/* Grizzly + reacting bubble */}
      <div className="relative flex flex-col items-center gap-4">
        <AnimatePresence mode="wait">
          <SpeechBubble key={phase === 'idea' ? 'idea' : phase === 'think' ? 'think' : bucket.text}>
            {phase === 'idea' ? (
              'lets put that to the test then >:3'
            ) : phase === 'think' ? (
              <ThinkingDots />
            ) : (
              bucket.text
            )}
          </SpeechBubble>
        </AnimatePresence>

        <motion.div
          animate={
            phase === 'idea'
              ? { rotate: [0, -4, 4, 0], y: [0, -6, 0] }
              : phase === 'think'
                ? { rotate: [0, -2, 2, 0] }
                : { y: [0, -3, 0] }
          }
          transition={{
            duration: phase === 'think' ? 0.8 : 2,
            repeat: Infinity,
            ease: 'easeInOut',
          }}
        >
          <Grizzly
            emotion={emotion}
            suited
            accessory={phase === 'idea' ? '💡' : phase === 'think' ? '💭' : undefined}
            size={120}
          />
        </motion.div>
      </div>

      {/* the meter */}
      <div className="w-full px-2">
        <div className="mb-2 flex items-center justify-between font-serif text-xs tracking-[0.3em] text-muted-foreground uppercase">
          <span>0%</span>
          <span className="text-base font-semibold text-wax">{value}%</span>
          <span>100%</span>
        </div>

        <div className="relative">
          <div className="h-3 w-full overflow-hidden rounded-full border border-gilt/30 bg-secondary">
            <motion.div
              className="h-full rounded-full bg-gradient-to-r from-wax-dark via-wax to-gilt"
              style={{ width: `${value}%` }}
              transition={{ type: 'spring', stiffness: 200, damping: 30 }}
            />
          </div>
          <input
            type="range"
            min={0}
            max={100}
            value={value}
            disabled={phase !== 'slide'}
            onChange={(e) => handleChange(Number(e.target.value))}
            aria-label="Love meter"
            className="love-range absolute inset-0 h-3 w-full cursor-pointer appearance-none bg-transparent disabled:cursor-default"
          />
        </div>
      </div>

      {/* start test */}
      <div className="h-14">
        <AnimatePresence>
          {phase === 'idea' ? (
            <motion.button
              type="button"
              onClick={onStart}
              initial={{ opacity: 0, y: 12, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.96 }}
              className="flex items-center gap-2 rounded-full border border-gilt/50 bg-wax px-7 py-3 font-serif text-lg tracking-[0.15em] text-paper uppercase shadow-[0_0_28px_-4px_var(--gilt)] transition-shadow hover:shadow-[0_0_40px_-2px_var(--gilt)] focus-visible:ring-2 focus-visible:ring-gilt focus-visible:outline-none"
            >
              Start Test
              <Rocket className="h-5 w-5" aria-hidden="true" />
            </motion.button>
          ) : null}
        </AnimatePresence>
      </div>
    </div>
  )
}

function ThinkingDots() {
  return (
    <span className="inline-flex items-center gap-1.5 py-1">
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="inline-block h-2 w-2 rounded-full bg-ink-soft"
          animate={{ y: [0, -5, 0], opacity: [0.4, 1, 0.4] }}
          transition={{ duration: 0.9, repeat: Infinity, delay: i * 0.18 }}
        />
      ))}
    </span>
  )
}
